Das Abenteuer besteht aus den folgenden Dateien:
 * duckcreek.pdf > Das Abenteuer selbst
 * kalender.pdf > Die wichtigsten Daten des Abenteuers auf einen Blick.
 * karte_dm.png > Die Übersichtskarte in der Version für den DM. Hier sind die Namen aller Orte eingezeichnet, die die Spieler entdecken können.
 * karte_spieler.png > Die Übersichtskarte für die Spieler.
 * personen.pdf > Die Werte aller Personen im Abenteuer bezogen auf das Quests of Chaos (https://quests-of-chaos.com/) Regelwerk.